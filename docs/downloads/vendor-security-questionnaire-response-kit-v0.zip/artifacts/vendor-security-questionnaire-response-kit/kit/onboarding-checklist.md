# Onboarding checklist (15–30 min)

Goal: create your internal “Standard Security Responses” doc once, then reuse.

## 1) Fill placeholders
- CompanyName / ProductName
- Hosting provider + data regions
- Security contact email
- Privacy policy URL
- Subprocessor list URL (even a simple page is fine)

## 2) Evidence pack (minimum viable)
- MFA enforcement screenshot (admin/IdP)
- Basic system diagram + data flow diagram
- Backup config + one restore test proof
- Example audit logs (admin actions, auth)

## 3) Decide your standard statements
- SSO support statement (truthful; include roadmap if needed)
- Pen test/testing statement (truthful; include roadmap if needed)
- RTO/RPO statement (even qualitative is better than blank)

## 4) Create your “Standard Security Responses” doc
- Copy sections from `answer-bank.md`
- Keep one canonical version to prevent contradictions

## 5) Use on every questionnaire
- Copy/paste answers
- Attach evidence
- If asked for policies/diagrams, share under NDA

Note: Not legal advice. Not a certification.
