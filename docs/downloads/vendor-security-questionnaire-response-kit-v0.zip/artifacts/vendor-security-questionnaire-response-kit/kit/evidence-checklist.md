# Evidence Checklist (v0)

Use this as a “what to attach” checklist when customers ask for proof.

## Policies (typical)
- Acceptable Use Policy (AUP)
- Access Control Policy
- Change Management Policy / Procedure
- Incident Response Plan
- Business Continuity / Disaster Recovery Plan
- Vulnerability Management Policy
- Vendor / Subprocessor Management Procedure

## Technical evidence (common)
- MFA enforcement screenshot (admin + IdP)
- Access review record (quarterly or monthly)
- Audit log screenshots (auth, admin actions)
- Backup configuration + last restore test evidence
- Encryption configuration evidence (TLS, storage encryption)
- Security training completion record (if applicable)

## Architecture / data flow
- High-level system diagram
- Data flow diagram (where PII may be stored/processed)
- Asset inventory (systems/services in scope)

## Compliance / attestations (if applicable)
- SOC 2 report (Type I/II) — if available
- ISO 27001 certificate — if available
- Pen test executive summary — if available

## Customer-ready statements to prepare
- Subprocessor list URL
- Security contact email
- Privacy policy URL
- Data residency regions
