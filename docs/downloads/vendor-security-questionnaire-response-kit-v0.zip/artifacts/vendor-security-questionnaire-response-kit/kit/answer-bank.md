# Answer Bank (v0)

Replace placeholders:
- {{CompanyName}}
- {{ProductName}}
- {{SecurityContactEmail}}
- {{DataRegions}}
- {{HostingProvider}}
- {{SubprocessorsUrl}}
- {{PrivacyPolicyUrl}}

---

## 1) Company & scope

**Q: Describe your service.**
- Short: {{CompanyName}} provides {{ProductName}}. We process customer data only to provide the service and support.
- Long: {{CompanyName}} provides {{ProductName}}. We process customer data to deliver the service, troubleshoot issues, provide support, and meet contractual obligations. We follow least-privilege access and log administrative actions.

**Q: Where is customer data stored/processed?**
- Short: Customer data is stored and processed in {{DataRegions}} using {{HostingProvider}}.
- Long: Customer data is stored and processed in {{DataRegions}} using {{HostingProvider}}. We maintain documented data flow and asset inventory and restrict administrative access to authorized personnel.

## 2) Governance & policies

**Q: Do you have an information security program?**
- Short: Yes. We maintain an information security program with documented policies, risk management, and incident response procedures.
- Long: Yes. Our information security program includes documented policies and standards, access control, change management, incident response, vendor management, and business continuity planning. Policies are reviewed periodically and updated as needed.

**Q: Do you have security policies available?**
- Short: Yes. Relevant policies can be provided under NDA upon request.
- Long: Yes. We maintain documented policies (acceptable use, access control, change management, incident response, and business continuity/disaster recovery). We can share relevant excerpts or full documents under NDA.

## 3) Access control

**Q: Is MFA required?**
- Short: MFA is required for administrative access.
- Long: MFA is required for administrative access. We use role-based access control and least privilege, and we review access on a periodic basis.

**Q: How do you provision/deprovision access?**
- Short: Access is provisioned based on role and removed promptly upon role change/termination.
- Long: Access is provisioned through a documented process based on role and least privilege. Access is removed promptly upon role change or termination. Administrative actions are logged.

## 4) Encryption

**Q: Is data encrypted in transit and at rest?**
- Short: Yes. We use TLS for data in transit and encryption at rest where supported by our storage providers.
- Long: Yes. We use TLS for data in transit. We use encryption at rest where supported by our storage providers and enforce secure key management practices appropriate to the services in use.

## 5) SDLC / change management

**Q: Do you have a change management process?**
- Short: Yes. Changes are reviewed and tracked.
- Long: Yes. We use a documented change management process including peer review, testing, and tracked deployments. High-risk changes require additional review and approval.

**Q: Do you perform vulnerability scanning/patching?**
- Short: Yes. We monitor for vulnerabilities and patch within defined timelines.
- Long: Yes. We monitor for vulnerabilities affecting our systems and dependencies and patch within defined timelines based on severity and exposure.

## 6) Logging & monitoring

**Q: Do you log security events?**
- Short: Yes. We log key security events and monitor for anomalies.
- Long: Yes. We log key security events (authentication, administrative actions, and system events) and monitor for anomalies. Logs are retained for an appropriate period to support incident investigation.

## 7) Incident response

**Q: Do you have an incident response plan?**
- Short: Yes.
- Long: Yes. We maintain an incident response process for triage, containment, eradication, recovery, and post-incident review. We notify customers as required by contract and applicable law.

**Q: What is your breach notification timeframe?**
- Short: We notify customers without undue delay in line with contractual and legal requirements.
- Long: We notify customers without undue delay in line with contractual and legal requirements, providing relevant details and remediation steps as information becomes available.

## 8) Business continuity / disaster recovery

**Q: Do you have backups?**
- Short: Yes. Backups are performed and tested.
- Long: Yes. We maintain backup procedures and periodically test restoration. We document recovery objectives appropriate to the service.

## 9) Vendor / subprocessor management

**Q: Do you use subprocessors?**
- Short: Yes, for infrastructure and operational tooling.
- Long: Yes, we use subprocessors for infrastructure and operational tooling. We assess vendors based on risk and contractually require appropriate security controls.

**Q: Where can we see your subprocessors?**
- Short: {{SubprocessorsUrl}}
- Long: We maintain a list of subprocessors here: {{SubprocessorsUrl}}

## 10) Privacy

**Q: Do you have a privacy policy?**
- Short: {{PrivacyPolicyUrl}}
- Long: We maintain a privacy policy here: {{PrivacyPolicyUrl}}. We handle personal data according to applicable requirements and minimize collection to what is necessary.
