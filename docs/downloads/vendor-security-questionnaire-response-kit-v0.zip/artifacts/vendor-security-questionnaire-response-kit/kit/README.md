# Vendor Security Questionnaire Response Kit (v0)

This kit is designed to help B2B SaaS teams respond to common vendor security questionnaires quickly and consistently.

## Contents
- `answer-bank.md` — copy/paste answers (short + long)
- `evidence-checklist.md` — what evidence to prepare/attach
- `questionnaire-mapper.md` — how to map common sections to SOC 2 / ISO 27001 language
- `red-flags-and-safer-answers.md` — common risky answers + safer alternatives

## How to use (fast)
1) Start with `answer-bank.md` and replace placeholders like:
   - {{CompanyName}}, {{Hosting}}, {{Regions}}, {{SubprocessorsUrl}}, {{SecurityContactEmail}}
2) Use `evidence-checklist.md` to gather attachments.
3) For each questionnaire, answer using the same phrasing across customers.

Note: This is documentation and guidance — not legal advice and not a certification.
