# Questionnaire Mapper (v0)

This is a lightweight mapping guide to keep your answers aligned with common compliance language.

## Typical questionnaire sections → where to answer

### Security program / governance
- Policies, roles/responsibilities, risk management
- SOC 2: Common Criteria (CC) governance-related controls
- ISO 27001: ISMS scope, leadership, planning (clauses 4–10) + Annex A topics

### Access control
- MFA, least privilege, provisioning/deprovisioning, access reviews
- SOC 2: logical access (CC6.x)
- ISO 27001: access control-related Annex A controls

### Encryption / key management
- TLS, encryption at rest, key management responsibilities
- SOC 2: system operations + confidentiality criteria
- ISO 27001: cryptography-related Annex A controls

### Change management / SDLC
- Reviews, testing, approvals, deployment logging
- SOC 2: change management (CC8.x)
- ISO 27001: change management / secure development Annex A topics

### Logging / monitoring
- Audit logs, alerting, retention
- SOC 2: system operations/monitoring criteria
- ISO 27001: logging/monitoring related Annex A topics

### Incident response
- Detection, escalation, notification, postmortems
- SOC 2: incident response (CC7.x)
- ISO 27001: incident management related Annex A topics

### Business continuity / disaster recovery
- Backups, restore tests, RTO/RPO, DR exercises
- SOC 2: availability criteria (if in scope)
- ISO 27001: BCDR related Annex A topics

### Vendor / subprocessor management
- Due diligence, contract security requirements, periodic reviews
- SOC 2: vendor management expectations
- ISO 27001: supplier relationship topics (supplier agreements, changes)

## How to use
- Keep a single “standard responses” document.
- When a questionnaire asks for a control, answer once in your own words, then reuse.
- If you don’t have a control yet, avoid saying “we don’t do X”; instead state the current practice + planned timeline (truthfully).
