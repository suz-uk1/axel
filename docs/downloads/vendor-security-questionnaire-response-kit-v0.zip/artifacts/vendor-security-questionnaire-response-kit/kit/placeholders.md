# Placeholders to customize (v0)

Replace these tokens across the kit.

## Core
- `{{CompanyName}}`
- `{{ProductName}}`
- `{{SecurityContactEmail}}`
- `{{HostingProvider}}`
- `{{DataRegions}}`

## Privacy / subprocessor
- `{{PrivacyPolicyUrl}}`
- `{{SubprocessorsUrl}}`

## SSO / IAM
- `{{SSOSupportStatement}}`
- `{{SSOSupportStatementLong}}`

## Pen test / security testing
- `{{PenTestStatement}}`
- `{{PenTestStatementLong}}`

## BCDR
- `{{RTO_RPO_Statement}}`
- `{{RTO_RPO_StatementLong}}`

## Tips
- Keep the “short” version as your default for questionnaires.
- Use “long” only when a buyer asks for detail.
- Avoid absolute statements you can’t evidence.
