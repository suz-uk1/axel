# Red flags + safer alternatives (v0)

This is not about hiding gaps. It’s about answering precisely so you don’t trigger unnecessary escalation.

## 1) “We don’t do pen tests.”
- Better: “We perform risk-based security testing. For high-risk changes we increase review/testing and can share our current testing approach upon request. Formal third‑party testing is on our roadmap.”

## 2) “We have no incident response plan.”
- Better: “We have an incident response process covering triage, containment, recovery, and customer notification. We can share an overview under NDA.”

## 3) “Everyone has admin access.”
- Better: “Admin access is restricted to authorized personnel with MFA, least privilege, and periodic reviews.”

## 4) “We store passwords in plaintext.”
- Better: Never say this; fix immediately. State: “Passwords are hashed using industry-standard algorithms; plaintext passwords are not stored.”

## 5) “We are fully compliant/certified.” (when you are not)
- Better: “We align our controls with commonly requested frameworks (e.g., SOC 2 / ISO 27001). We can share our current control set and roadmap.”

## 6) Over-sharing sensitive details
- Better: Provide high-level descriptions; share sensitive diagrams/policies only under NDA.

## 7) Absolute statements you can’t prove
- Avoid: “We never have incidents.”
- Better: “We monitor for security events and have an incident response process. We will notify customers per contract/law.”
