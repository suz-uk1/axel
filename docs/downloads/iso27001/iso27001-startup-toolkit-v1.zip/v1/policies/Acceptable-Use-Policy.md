# Acceptable Use Policy (Template)

**Owner:** <Name/Role>  
**Effective date:** <YYYY-MM-DD>  
**Version:** 0.1

## 1. Purpose
Define acceptable use of company systems and information.

## 2. Scope
All users and all company-managed or company-authorized devices, accounts, and networks.

## 3. Acceptable use
Users must:
- Use company systems primarily for business purposes
- Protect credentials and enable MFA where required
- Lock screens when unattended
- Store company data only in approved services
- Report suspected phishing or security incidents promptly

## 4. Prohibited use
Users must not:
- Share passwords or MFA tokens
- Install unapproved software that increases risk
- Bypass security controls
- Use company systems for illegal activities
- Exfiltrate company or customer data without authorization

## 5. Data handling
- Follow the Data Classification & Handling Policy
- Do not store sensitive data in personal accounts

## 6. Monitoring
Company systems may be monitored for security and compliance.

## 7. Acknowledgement
Users acknowledge and agree to follow this policy.
