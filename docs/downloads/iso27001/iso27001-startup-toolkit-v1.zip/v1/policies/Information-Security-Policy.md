# Information Security Policy (Template)

**Document owner:** <Name/Role>  
**Approved by:** <Name/Role>  
**Effective date:** <YYYY-MM-DD>  
**Version:** 0.1

## 1. Purpose
This policy defines the organization’s intent and minimum requirements to protect information and systems, consistent with ISO/IEC 27001.

## 2. Scope
Applies to:
- All employees, contractors, and temporary staff
- All information assets (data, code, infrastructure, devices)
- All environments (production, staging, development)

## 3. Policy statement
We will:
- Identify and manage information security risks
- Implement proportionate controls based on risk and business needs
- Maintain documented procedures for key security activities
- Train personnel on security responsibilities
- Monitor, detect, and respond to security incidents
- Continually improve the ISMS via audits, reviews, and corrective actions

## 4. Roles and responsibilities
- **Top management:** sets direction, approves ISMS scope, provides resources
- **ISMS owner/security owner:** maintains policies, drives risk management, ensures evidence
- **System owners:** implement controls, maintain configurations, collect logs/evidence
- **All personnel:** follow policies, report suspected incidents

## 5. Risk management
- Maintain a **Risk Register** including likelihood/impact and treatment
- Review risks at least <quarterly> and upon significant changes

## 6. Compliance
Violations may result in disciplinary action up to termination, and contractual remedies.

## 7. Exceptions
Exceptions require documented approval by the ISMS owner and a defined expiry date.

## 8. Document control
- Changes must be recorded in the change log
- Review this policy at least annually
