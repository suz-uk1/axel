# Access Control Policy (Template)

**Owner:** <Name/Role>  
**Effective date:** <YYYY-MM-DD>  
**Version:** 0.1

## 1. Purpose
Define requirements to ensure only authorized users and systems access information and services.

## 2. Scope
All systems, applications, data stores, and endpoints used to process organizational information.

## 3. Principles
- **Least privilege** by default
- **Separation of duties** for sensitive actions
- **Strong authentication** for privileged access
- **Access is time-bound** where practical

## 4. Requirements
### 4.1 Account lifecycle
- Access requests must be approved by <manager/system owner>.
- Accounts must be provisioned using centralized identity where possible.
- Deprovisioning must occur within <24–72h> of role change/termination.

### 4.2 Authentication
- MFA required for:
  - Admin accounts
  - Production access
  - Email and source control
- Passwords must meet minimum length <12+> and be stored using approved password managers.

### 4.3 Authorization
- Use role-based access (RBAC) where possible.
- Privileged roles must be documented.

### 4.4 Reviews
- Access reviews for critical systems at least <quarterly>.
- Evidence: access review log and access request records.

### 4.5 Logging
- Log authentication events and privileged actions where possible.

## 5. Exceptions
Documented exceptions require expiry and compensating controls.

## 6. Review
Annual review or after major incidents/changes.
