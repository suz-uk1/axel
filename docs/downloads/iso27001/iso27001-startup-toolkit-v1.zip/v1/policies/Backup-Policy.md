# Backup Policy (Template)

**Owner:** <Name/Role>  
**Effective date:** <YYYY-MM-DD>  
**Version:** 0.1

## 1. Purpose
Define backup requirements to ensure data and systems can be restored after incidents or failures.

## 2. Scope
Production data stores, critical SaaS, and infrastructure configurations.

## 3. Requirements
- Define backup scope for each critical system (data + configuration).
- Backups must be:
  - Encrypted
  - Access-controlled
  - Tested periodically

### 3.1 Frequency (example)
- Databases: daily + point-in-time recovery if available
- Object storage: daily snapshots/versioning
- Infrastructure-as-code repos: continuous (via source control)

### 3.2 Retention (example)
- Daily backups: 14–30 days
- Monthly backups: 3–12 months

### 3.3 Testing
- Perform restore tests at least <quarterly>.
- Document results and corrective actions.

## 4. Evidence
- Backup configuration screenshots/exports
- Restore test records

## 5. Review
Annual review.
