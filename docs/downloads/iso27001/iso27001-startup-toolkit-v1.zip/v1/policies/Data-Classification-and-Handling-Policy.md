# Data Classification & Handling Policy (Template)

**Owner:** <Name/Role>  
**Effective date:** <YYYY-MM-DD>  
**Version:** 0.1

## 1. Purpose
Define data classification levels and handling requirements.

## 2. Scope
All organizational data, including customer and employee data.

## 3. Classification levels (example)
- **Public:** intended for public release
- **Internal:** non-public business information
- **Confidential:** sensitive business or customer data
- **Restricted:** highest sensitivity (e.g., secrets, credentials)

## 4. Handling requirements
### 4.1 Storage
- Confidential/Restricted data must be stored only in approved systems with access controls.

### 4.2 Transmission
- Use encryption in transit; prohibit sending Restricted data over insecure channels.

### 4.3 Access
- Access must follow least privilege and be reviewed periodically.

### 4.4 Retention & disposal
- Retain data only as long as needed for business/legal purposes.
- Dispose securely (wipe, delete, destroy) per procedures.

## 5. Examples
- Customer production database exports: **Restricted**
- Source code: **Confidential**
- Marketing site content: **Public**

## 6. Review
Annual review.
