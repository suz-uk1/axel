# Change Management Policy (Template)

**Owner:** <Name/Role>  
**Effective date:** <YYYY-MM-DD>  
**Version:** 0.1

## 1. Purpose
Define how changes to production systems are planned, reviewed, tested, approved, and recorded.

## 2. Scope
All changes to production infrastructure, applications, and security configurations.

## 3. Requirements
- Record changes in <ticketing system / PRs>.
- Classify changes (standard/normal/emergency).
- Require peer review for production code changes.
- Require approvals for high-risk changes.

### 3.1 Testing & rollback
- Changes must be tested prior to deployment.
- Define rollback procedures for critical systems.

### 3.2 Emergency changes
- Allowed only to restore service or mitigate risk.
- Must be reviewed retrospectively within <2 business days>.

## 4. Evidence
- Change tickets / PRs
- Release notes / deployment logs
- Emergency change retrospective notes

## 5. Review
Annual review.
