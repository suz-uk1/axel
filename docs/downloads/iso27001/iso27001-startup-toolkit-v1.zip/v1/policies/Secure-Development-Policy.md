# Secure Development Policy (Template)

**Owner:** <Name/Role>  
**Effective date:** <YYYY-MM-DD>  
**Version:** 0.1

## 1. Purpose
Define minimum security practices for software development.

## 2. Scope
All software developed or maintained by the organization.

## 3. Requirements
### 3.1 Source control
- Use pull requests and peer review for production changes.
- Protect main branches; require status checks.

### 3.2 Dependency management
- Track dependencies.
- Use automated scanning where possible.
- Patch critical vulnerabilities within defined SLAs.

### 3.3 Secrets
- Store secrets in approved secret managers.
- Prohibit committing secrets to repositories.

### 3.4 Code security
- Use secure coding guidelines.
- Validate input, use least privilege for services.

### 3.5 Deployments
- Use CI/CD with auditable logs.
- Separate duties where possible (review vs deploy).

## 4. Evidence
- PR history and branch protection settings
- Scan outputs
- Secrets management documentation

## 5. Review
Annual review.
