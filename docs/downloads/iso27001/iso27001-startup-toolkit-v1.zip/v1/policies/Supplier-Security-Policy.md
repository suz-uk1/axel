# Supplier Security Policy (Template)

**Owner:** <Name/Role>  
**Effective date:** <YYYY-MM-DD>  
**Version:** 0.1

## 1. Purpose
Define minimum security requirements for third parties that access or process company information.

## 2. Scope
All suppliers, contractors, and SaaS providers that:
- Access company/customer data
- Provide critical services
- Are integrated into production workflows

## 3. Requirements
### 3.1 Classification
Suppliers must be classified by risk (e.g., Low/Medium/High) based on data sensitivity and criticality.

### 3.2 Due diligence
For Medium/High risk suppliers, collect at least one of:
- Security questionnaire responses
- SOC 2 report, ISO 27001 certificate, or equivalent
- Pen test summary or security whitepaper

### 3.3 Contractual controls
Contracts should include (as applicable):
- Confidentiality and data protection obligations
- Incident notification timelines
- Right to audit / security assurances
- Sub-processor requirements

### 3.4 Ongoing monitoring
- Review high-risk suppliers at least annually.
- Maintain a vendor list and review log.

## 4. Evidence
- Vendor inventory
- Completed questionnaires/reports
- Review notes and approvals

## 5. Review
Annual review.
