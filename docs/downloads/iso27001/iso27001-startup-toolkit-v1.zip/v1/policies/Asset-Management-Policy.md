# Asset Management Policy (Template)

**Owner:** <Name/Role>  
**Effective date:** <YYYY-MM-DD>  
**Version:** 0.1

## 1. Purpose
Ensure information assets are identified, owned, and managed throughout their lifecycle.

## 2. Scope
All information assets including software, infrastructure, devices, data, and services.

## 3. Requirements
- Maintain an **Asset Inventory** including owner, location, classification, and criticality.
- Asset owners must:
  - Ensure appropriate controls are implemented
  - Review access and configuration periodically
  - Ensure assets are retired securely

## 4. Asset lifecycle
### 4.1 Onboarding
- New assets must be recorded before production use.

### 4.2 Changes
- Material changes to critical assets must follow Change Management.

### 4.3 Disposal
- Devices and media must be wiped or destroyed per approved procedures.
- SaaS accounts must be deprovisioned and access removed.

## 5. Evidence
- Asset inventory export
- Disposal/wipe records (where applicable)

## 6. Review
Annual review.
