# Logging & Monitoring Policy (Template)

**Owner:** <Name/Role>  
**Effective date:** <YYYY-MM-DD>  
**Version:** 0.1

## 1. Purpose
Define minimum logging and monitoring to support detection, investigation, and audit evidence.

## 2. Scope
All production systems, identity providers, key applications, and critical SaaS.

## 3. Requirements
### 3.1 Logging
Log at minimum:
- Authentication events (success/failure), MFA changes
- Privileged/admin actions
- Key application events (e.g., permission changes)
- Security-relevant configuration changes

### 3.2 Protection
- Logs must be protected from tampering.
- Restrict access to logs.

### 3.3 Retention
- Retain logs for at least <90–180 days> (or per regulatory/customer requirements).

### 3.4 Monitoring
- Define alerting for suspicious events (e.g., repeated login failures, unusual admin actions).
- Maintain an on-call/response path (even if minimal).

## 4. Evidence
- Logging configuration exports
- Alert definitions
- Sample investigation notes

## 5. Review
Annual review.
