# Incident Response Policy (Template)

**Owner:** <Name/Role>  
**Effective date:** <YYYY-MM-DD>  
**Version:** 0.1

## 1. Purpose
Define a consistent approach for detecting, responding to, and learning from security incidents.

## 2. Scope
All security incidents affecting confidentiality, integrity, or availability of systems and data.

## 3. Definitions
- **Security incident:** an event that compromises or threatens security.
- **Severity levels:** Sev1 (critical) → Sev3 (low) (define as needed).

## 4. Roles
- Incident commander: <role>
- Communications: <role>
- Technical responders: <role>

## 5. Process
1) **Detect & report** (alerts, user reports)
2) **Triage** (severity, scope, data impact)
3) **Contain** (short-term + long-term)
4) **Eradicate & recover**
5) **Notify** (customers/regulators if required)
6) **Post-incident review** (root cause, CAPA)

## 6. Requirements
- Maintain an incident log with timeline.
- Preserve evidence (logs, snapshots) where possible.
- Conduct a post-incident review for Sev1/Sev2 within <5 business days>.

## 7. Evidence
- Incident reports and timelines
- Post-incident review notes
- CAPA records

## 8. Review
Annual review.
