# How to fill the Statement of Applicability (SoA) — Startup guide

Goal: produce an SoA that is *consistent* with your risk assessment and evidence, and defensible to an auditor.

## What auditors want to see
For each control (ISO 27001:2022 Annex A):
1) **Applicability decision** (Applicable / Not applicable)
2) **Justification** (why)
3) **Implementation status** (Implemented / Partially / Planned)
4) **Evidence** (what proves it)

The SoA should be consistent with:
- Risk Register (risks that drive controls)
- Evidence Map (artifacts that prove controls)
- CAPA log (findings and fixes)

## Step-by-step
1) **Define scope** (systems, teams, locations)
2) **Complete risk assessment** → populate the Risk Register
3) For each risk, decide which controls address it
4) Populate SoA rows:
   - Set applicability
   - Write a short justification (1–3 sentences)
   - Link evidence (docs, configs, logs)

## Example justifications (copy/paste starters)
### Applicable — common SaaS startup
- **Access control**: "Applicable. We use cloud services and production environments that require controlled access. The control reduces unauthorized access risk." 
- **Logging**: "Applicable. We need audit trails for authentication and administrative actions to detect and investigate incidents." 
- **Supplier security**: "Applicable. Critical business functions rely on third-party SaaS providers processing company/customer data. We must assess and monitor supplier risk." 

### Not applicable — acceptable cases
Not applicable must be rare and defensible.
- **Physical security controls** (if no offices / no on-prem): "Not applicable. The organization has no on-premises facilities under its control; all infrastructure is hosted by <cloud provider> and controlled via contractual and logical controls." 
- **On-prem media handling** (if no removable media use): "Not applicable. The organization does not use removable media for information processing; data transfer is performed via approved encrypted channels." 

## Common mistakes
- Marking controls "Not applicable" to avoid work (auditors push back)
- SoA doesn’t reference evidence (Stage 2 becomes painful)
- Risk Register and SoA drift (findings)

## Practical tip
Treat SoA as a living map:
- Update when major systems change
- Update after audits/incidents (CAPA)
- Re-run access reviews and supplier reviews on a schedule
