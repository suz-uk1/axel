# ISO 27001 Startup Toolkit (v1)

This is a lightweight, startup-friendly set of ISO 27001 working templates + checklists designed to help you move fast and stay audit-consistent.

## What’s inside
### Templates (CSV — import into Google Sheets / Excel)
- `templates/soa-template.csv` — Statement of Applicability table layout
- `templates/risk-register-template.csv` — Risk register layout + example rows
- `templates/internal-audit-plan-template.csv` — Internal audit plan / sampling checklist
- `templates/management-review-minutes-template.csv` — Management review minutes format
- `templates/capa-log-template.csv` — Corrective action (CAPA) log
- `templates/audit-evidence-pack-template.csv` — Stage 2 evidence map checklist
- `templates/vendor-risk-register-template.csv` — Supplier/vendor risk register layout

### Docs
- `docs/implementation-path.md` — the recommended order to implement
- `docs/how-to-use-csv-templates.md` — import tips + conventions
- `docs/license.txt` — single-company use (draft; adjust as needed)

## Recommended implementation order (fast)
1) Set scope
2) Run risk assessment → fill risk register
3) Complete SoA (justify applicability) + link to evidence
4) Implement procedures + collect evidence
5) Internal audit → findings → CAPA
6) Management review minutes

## Support
If you have questions, reply to your purchase email or message on LinkedIn:
https://www.linkedin.com/in/axel-astro-6390913b9/
