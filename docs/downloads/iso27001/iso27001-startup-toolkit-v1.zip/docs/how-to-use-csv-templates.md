# How to use the CSV templates

## Import into Google Sheets
1) Create a new Google Sheet
2) File → Import → Upload → select the CSV
3) Choose: “Replace spreadsheet” or “Insert new sheet(s)”

## Import into Excel
- Open the CSV directly, then Save As `.xlsx`.

## Conventions
- Keep a single source of truth (one sheet per template).
- Use links for evidence (tickets, documents, screenshots, configs).
- Keep columns stable; add new columns only if you need them.

## Audit tip
Auditors love traceability. The recurring pattern is:
scope → risks → SoA → procedures → evidence.
If these stay consistent, audits become sampling.
