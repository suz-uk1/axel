# Implementation path (startup-friendly)

This is a practical path that keeps documentation + evidence consistent.

## 1) Scope
- Decide what systems/teams/locations are in-scope.
- Keep it narrow enough that you can actually maintain evidence.

## 2) Asset/process inventory (lightweight)
- List your “crown jewels” (production customer data systems, key SaaS, CI/CD, IAM, laptops).

## 3) Risk assessment + risk register
- Use a simple, consistent scoring model.
- Assign owners and due dates to treatments.

## 4) SoA (Statement of Applicability)
For each control:
- Applicable? (Y/N)
- Why (risk/scope/requirement)
- Status
- Owner
- Evidence pointer

## 5) Evidence map
- Build the evidence pack checklist: control/topic → evidence → source system → period → link.

## 6) Internal audit
- Audit workflows, not documents:
  - JML access changes
  - change management
  - backups/restore tests
  - supplier risk sample

## 7) CAPA
- Track nonconformities to closure with effectiveness verification.

## 8) Management review
- Decision-oriented minutes:
  - what changed
  - what risks matter
  - actions + owners + due dates
  - evidence links
