# ISO 27001 Stage 2 Evidence Pack (v1)

**Goal:** make Stage 2 evidence collection predictable in 7 days.

## Who this is for
- Startups preparing for **ISO 27001 Stage 2** (or a surveillance audit)
- You already have *some* policies/SoA, but evidence is messy
- You need a clean, auditor-friendly evidence map fast

## What’s inside
- `templates/evidence-map-template.csv`
  - Evidence Map template (controls → evidence items → owners → links)
- `examples/evidence-map-example.csv`
  - Filled example to copy
- `docs/7-day-evidence-sprint.md`
  - A practical plan to fill the evidence map in a week
- `docs/stage2-evidence-checklist.md`
  - The “what auditors ask for” checklist

## How to use (quick start)
1) Copy `templates/evidence-map-template.csv`
2) Open it in Google Sheets.
3) Start with the top 20 controls in your scope.
4) Fill **Owner + Link + Last updated** for each evidence item.
5) Run the 7‑day sprint plan.

## Notes
- Informational only; not a guarantee of certification outcome.
