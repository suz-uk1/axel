# 7‑Day Stage 2 Evidence Sprint (copy/paste plan)

**Objective:** In 7 days, produce an auditor-friendly Evidence Map with working links for the evidence you already have, and a clear plan to generate the missing pieces.

## Day 0 (30 minutes): Setup
- Create a folder: `ISMS/Evidence/Stage2/<YYYY-MM>/`
- Put the Evidence Map sheet at the top (Google Sheets recommended).
- Decide roles:
  - Evidence owner (security lead)
  - Link owner per system (AWS/GCP, HR, engineering, support)

## Day 1: Scope → control shortlist
- Confirm scope (systems, products, locations)
- Pick the **top 20–30 controls** you will prove first (the ones auditors ask about)
- In the Evidence Map, fill:
  - Control / Evidence name / Owner / Evidence link column headers

## Day 2: Access + identity evidence
Collect links/screenshots/log exports for:
- User onboarding/offboarding process
- Access request/approval trail (ticket or PR)
- MFA enforcement evidence
- Periodic access review evidence (even a simple spreadsheet)

## Day 3: Change management + SDLC
- PR review rules + protected branches
- Deployment pipeline logs
- Secure coding practices evidence (SAST/secret scanning if applicable)
- Vulnerability fix workflow (tickets/SLAs)

## Day 4: Logging + monitoring
- Central logging setup (what is logged, retention)
- Alerting rules
- Incident triage evidence (tickets, on-call, postmortems)

## Day 5: Backup + recovery
- Backup configuration
- Restore test evidence (at least one test record)
- RTO/RPO statements aligned with risk

## Day 6: Supplier + asset management
- Vendor list and risk review evidence
- Asset inventory evidence
- Key supplier contracts / DPA pointers (links)

## Day 7: Internal audit rehearsal
- Pick 10 random evidence items and open the links live
- Mark broken links / missing owners
- Produce the “Gap list” tab: what’s missing, who owns it, due date

## Output you should have by the end
- Evidence Map sheet with:
  - Owners assigned
  - Links that open
  - Last updated values
  - A short gap list
