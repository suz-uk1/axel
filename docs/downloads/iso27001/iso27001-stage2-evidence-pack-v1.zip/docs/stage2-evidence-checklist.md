# Stage 2 Evidence Checklist (startup-friendly)

Use this as a **“do we have proof?”** list when preparing for ISO 27001 Stage 2.

## Access control
- [ ] Joiner/mover/leaver process evidence (ticket/HR workflow)
- [ ] MFA enforcement evidence (IdP settings screenshot)
- [ ] Privileged access management evidence (admin group review)
- [ ] Access review evidence (quarterly spreadsheet is fine)

## Secure development / change management
- [ ] Code review / approvals enforced
- [ ] CI/CD pipeline logs retained
- [ ] Secrets scanning / dependency scanning evidence (if used)
- [ ] Vulnerability remediation workflow + SLA evidence

## Logging / monitoring / incident response
- [ ] Centralized logging configuration
- [ ] Alert rules + on-call process
- [ ] Incident tickets + postmortem template evidence

## Backup / recovery
- [ ] Backup configuration evidence
- [ ] Restore test evidence (date + result)
- [ ] RTO/RPO documented and tied to risk

## Asset & supplier management
- [ ] Asset inventory (systems + data stores)
- [ ] Vendor list + security review evidence
- [ ] Key supplier contracts/DPA links

## Governance
- [ ] SoA is consistent with scope + risk
- [ ] Internal audit plan + at least one internal audit record
- [ ] Management review minutes with decisions + actions

## Output quality checks
- [ ] Every evidence item has an owner
- [ ] Every link opens without special permissions
- [ ] Every screenshot has a timestamp
- [ ] Evidence is stored under a consistent folder structure
