# Distribution assets — Clinic Ransomware Readiness Pack (APPI‑friendly)

## 1) LinkedIn post (founder-style)
**Hook:** Ransomware is hitting small clinics too.

Small clinics don’t need a “security program.” They need a calm plan for the first hour.

I put together a **Clinic Ransomware Readiness Pack (APPI‑friendly)**:
- printable incident checklist (first 60 min / 24h / 7d)
- simple backup & restore policy template
- vendor questionnaire for IT/EHR/backup providers
- staff one‑pager + suspected-incident flow

Designed for **1–30 staff** clinics that can’t justify expensive consulting.

If you want it, comment **“CLINIC”** and I’ll share the link.

(Free to adapt internally. Not legal advice.)

---

## 2) X (Twitter) post (short)
Ransomware isn’t “big-company only.” Small clinics get hit—and the first 60 minutes are chaos.

I’m shipping a **Clinic Ransomware Readiness Pack (APPI‑friendly)**: incident checklist + backup policy + vendor questionnaire + staff one‑pager.

Reply “CLINIC” and I’ll DM the link.

---

## 3) Cold/warm outreach email to clinics (admin/owner)
**Subject options:**
- Ransomware checklist for small clinics (printable)
- Quick question: your clinic’s ransomware plan
- Incident checklist + vendor questions (clinic-ready)

**Email:**
Hi <Name>,

I’m reaching out because ransomware incidents are increasingly affecting smaller clinics—and the hard part is rarely “technology.” It’s the lack of a clear, documented playbook for the first hour.

I put together a **Clinic Ransomware Readiness Pack (APPI‑friendly)** designed for small clinics (1–30 staff):
- a printable incident checklist (first 60 minutes / 24h / 7d)
- a simple backup & restore policy template
- a vendor questionnaire for your IT/EHR/backup providers
- a staff one‑pager + suspected-incident flow

If you’d like, I can share the link.

Question: do you already have a written incident checklist and a tested restore process?

Best,
Axel

---

## 4) Simple execution plan (next 48 hours)
1) Post on LinkedIn + X once.
2) Send 30 emails to clinic administrators/owners (manually sourced from public clinic websites; no scraping behind paywalls).
3) Offer a 10-minute call only if asked; default is one-time purchase.
4) Iterate based on replies: which template drives most interest (IR checklist vs backup policy).
