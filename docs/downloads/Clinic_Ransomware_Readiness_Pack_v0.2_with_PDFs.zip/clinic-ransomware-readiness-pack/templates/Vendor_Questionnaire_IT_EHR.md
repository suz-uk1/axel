# Vendor Questionnaire (IT Provider / EHR / Backup) — Clinic Security & Ransomware Readiness

**Clinic name:** <Clinic>

**Vendor name:** <Vendor>

**Contact:** <Name / Email / Phone>

**Date:** <YYYY-MM-DD>

## A) Service overview
1) What systems do you manage for us? (EHR, network, PCs, backups, email, imaging)
2) Who has admin access? (roles, not personal names)
3) What is your support SLA for incidents? (hours, response time)

## B) Access control
4) Do you support **MFA** for admin access and remote support tools? If yes, which?
5) Do you use shared admin accounts? If yes, how are they controlled/audited?
6) How is remote access implemented? (VPN, remote tool, RDP)

## C) Backup & restore
7) Do you provide backups? If yes:
   - schedule (daily/weekly)
   - retention (days/months)
   - location (cloud/on-prem)
8) Are backups **immutable** or **offline**? Describe.
9) When was the last restore test performed? Provide date and result.
10) What are the expected **RTO** (restore time) and **RPO** (data loss window)?

## D) Patch & vulnerability management
11) How do you handle OS/application updates? Frequency?
12) How quickly do you apply critical security patches?

## E) Endpoint protection
13) What antivirus/EDR is used? Is it centrally managed?
14) Do you block common ransomware behaviors? (macro controls, application allowlist, etc.)

## F) Incident response
15) If ransomware occurs, what is your step-by-step process in the first hour?
16) How do you preserve evidence and logs?
17) Will you support coordination with other vendors (EHR/backup/ISP)?

## G) Data handling & patient information
18) Where is patient data stored/processed?
19) Any subcontractors involved? If yes, list.
20) What logging/auditing is available for access to patient data?

## H) Confirmation & attachments
Please attach any relevant documents:
- backup schedule/retention policy
- incident response procedure (high-level)
- security certifications (if any)

**Vendor representative:** ____________________  **Date:** __________
