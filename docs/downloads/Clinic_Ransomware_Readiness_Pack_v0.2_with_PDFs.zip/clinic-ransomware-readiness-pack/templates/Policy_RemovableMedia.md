# Policy: Removable Media (USB) (Clinic)

**Document owner:** <Name/Role>

**Version:** 0.1 (Template)

## 1. Purpose
To reduce malware/ransomware risk from USB drives and other removable media.

## 2. Rules
- Staff must not use unknown USB drives.
- Clinic-approved USB drives only, labeled and tracked.
- Patient data must not be copied to removable media unless explicitly required and approved.

## 3. Approved use cases
- Vendor-required transfer for imaging equipment (if no safer option)
- Emergency transfer approved by clinic manager

## 4. Handling requirements
- Scan removable media with antivirus before use.
- Do not use personal devices to access clinic systems.
- Store approved drives in a secured location.

## 5. Exceptions
Any exception must be documented with reason + date.

**Approval:** ____________________  **Date:** __________
