# Suspected Incident Flow (Clinic) — Print & Post

## If you suspect ransomware / phishing compromise

1) **STOP** using the PC
2) **DISCONNECT** (Wi‑Fi OFF / unplug cable)
3) **CALL** clinic manager immediately

---

## Clinic manager: first actions
4) Start an **incident log** (time, who, what happened)
5) Call **IT provider** and **EHR vendor**
6) Decide: **continue limited operations** vs **pause** (patient safety first)

---

## Do NOT do
- Don’t pay or negotiate
- Don’t wipe the PC
- Don’t plug in USB drives
- Don’t reconnect “to see if it works”

---

## Helpful info to note
- What did the staff click/open?
- What message was shown? (photo/screenshot)
- Which systems are affected? (EHR, files, billing)
- When did it start?
