# Policy: Updates & Patching (Clinic)

**Document owner:** <Name/Role>

**Version:** 0.1 (Template)

## 1. Purpose
To reduce ransomware and malware risk by keeping operating systems and applications up to date.

## 2. Scope
- Staff PCs/laptops used for clinic operations
- Servers (if any)
- Network devices (router, firewall, Wi‑Fi)
- EHR / practice management software (vendor-managed or self-managed)
- Browsers and common apps (Office, PDF tools)

## 3. Minimum requirements
- **Automatic updates ON** where feasible.
- Critical security updates prioritized.
- Unsupported OS/software is removed or isolated.

## 4. Update schedule (baseline)
- **Weekly:** install OS/app updates on endpoints.
- **Monthly:** review updates for all systems and confirm completion.
- **Quarterly:** review network device firmware updates.

## 5. Critical vulnerability response
When a critical security issue is announced for software we use:
- Assess impact within **3 business days**.
- Apply fix/mitigation within **14 days** (or sooner per vendor guidance).

## 6. Exceptions
If an update cannot be applied (compatibility, vendor constraints):
- Document the reason.
- Apply compensating controls (restrict access, network isolation, extra monitoring).

## 7. Responsibilities
- Clinic manager: ensures schedule is followed.
- IT provider/vendor: executes updates and provides confirmation.

## 8. Compliance & review
Reviewed at least annually.

**Approval:** ____________________  **Date:** __________
