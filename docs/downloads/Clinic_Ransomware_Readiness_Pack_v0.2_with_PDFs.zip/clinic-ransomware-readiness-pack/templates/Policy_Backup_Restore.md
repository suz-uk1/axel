# Policy: Backup & Restore (Clinic)

**Document owner:** <Name/Role>

**Version:** 0.1 (Template)

**Applies to:** All systems that store or access patient information, scheduling, billing, imaging, and related clinic operations.

## 1. Purpose
To ensure clinic data can be restored quickly after ransomware, accidental deletion, device loss, or system failure.

## 2. Scope
- EHR / practice management system
- File shares / cloud storage
- Staff PCs/laptops used for clinic operations
- Imaging systems (as applicable)
- Email and shared documents (as applicable)

## 3. Backup principles (minimum baseline)
1) **3-2-1 approach:**
- At least **3** copies of important data
- Stored on at least **2** different media/services
- At least **1** copy **offline or immutable** (protected from ransomware encryption/deletion)

2) **Separation of duties:** backup admin credentials must not be used for daily work.

3) **Least privilege:** only designated roles can change backup settings or delete backups.

## 4. Backup schedule
- **Critical systems (EHR / scheduling / billing):** at least **daily** backups.
- **Clinic files / documents:** at least **daily** backups.
- **Device endpoints (PCs/laptops):** as needed; prefer centralized storage so endpoints are not single points of failure.

**Retention (minimum):**
- Daily backups kept for: **<e.g., 30 days>**
- Monthly backups kept for: **<e.g., 12 months>**

## 5. Offline / immutable backup requirement
At least one backup set must be protected from modification/deletion by malware:
- Immutable storage (WORM / object-lock) **or**
- Offline drive rotated and disconnected when not backing up

**Chosen method:** <Describe>

## 6. Restore testing
- **Frequency:** at least **quarterly** (every 3 months)
- **What to test:**
  - Restore one sample patient-related document set
  - Restore one critical system snapshot/export (where possible)
  - Verify integrity and access

**Record of test:** keep a dated log (who, what, result, time to restore).

## 7. Vendor responsibilities
If backups are managed by a vendor:
- Vendor must provide written confirmation of schedule, retention, and immutable/offline protections.
- Vendor must specify **RTO/RPO** targets:
  - **RTO (time to restore):** <target>
  - **RPO (data loss window):** <target>

## 8. Incident handling (if ransomware suspected)
- Do **not** connect potentially infected machines to backup consoles.
- Pause automated backup jobs if there is a risk they will back up encrypted data.
- Preserve evidence and follow the clinic Incident Checklist.

## 9. Compliance & review
- Reviewed at least annually and after any major system change.

**Approval:** ____________________  **Date:** __________
