# Policy: Phishing & Email Handling (Clinic)

**Document owner:** <Name/Role>

**Version:** 0.1 (Template)

## 1. Purpose
To reduce ransomware risk by preventing phishing-driven compromise.

## 2. Rules (simple)
1) **Do not open** unexpected attachments.
2) **Do not enable macros** in Office documents from email.
3) Verify payment/bank detail change requests **by phone** using known contact info.
4) Use the clinic’s approved file-sharing method; avoid sending patient data via personal email.

## 3. Suspicious email indicators
- urgent tone (“act now”, “account locked”)
- sender address slightly off
- unexpected invoice/shipping notice
- link destinations that don’t match the displayed text

## 4. What to do if you suspect phishing
- Do not click links or reply.
- Forward to: <security mailbox> or notify clinic manager.
- If you clicked something: disconnect from Wi‑Fi and report immediately.

## 5. Technical protections (recommended)
- Enable MFA on email accounts.
- Use spam filtering.
- Block common attachment types where appropriate.

## 6. Training
- 5-minute refresher at least twice a year.

**Approval:** ____________________  **Date:** __________
