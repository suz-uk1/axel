# Policy: Access Control & Account Management (Clinic)

**Document owner:** <Name/Role>

**Version:** 0.1 (Template)

**Applies to:** All staff, contractors, and vendors with access to clinic systems or patient information.

## 1. Purpose
To reduce unauthorized access risk by managing accounts, permissions, and authentication in a simple, auditable way.

## 2. Scope (systems)
- EHR / practice management
- Scheduling / billing
- Imaging systems (if applicable)
- Email and shared drives
- PCs/laptops used for clinic operations
- Remote support / VPN tools

## 3. Principles (minimum baseline)
1) **Unique accounts:** no shared logins for staff.
2) **Least privilege:** staff get only what they need.
3) **MFA where possible:** especially for admin, remote access, and cloud services.
4) **Fast offboarding:** remove access immediately when roles change or staff leave.

## 4. Account lifecycle
### 4.1 New staff onboarding
- Create user account(s) for required systems.
- Assign role-based permissions.
- Require strong password + MFA (where available).
- Record access granted (system + role + date).

### 4.2 Role changes
- Review permissions within **5 business days**.
- Remove unnecessary access.

### 4.3 Offboarding (staff leaving)
- Disable accounts **same day**.
- Reassign ownership of shared documents.
- Recover clinic-owned devices.

## 5. Password & authentication requirements
- Passwords must be unique and not reused across systems.
- Clinic uses a password manager for admin credentials (recommended).
- MFA is enabled for:
  - email
  - cloud storage
  - EHR (if supported)
  - remote support tools

## 6. Admin and vendor access
- Admin accounts are separate from daily-use accounts.
- Vendor access must be:
  - time-bound where possible
  - logged/audited
  - removed when not needed

## 7. Reviews
- Quarterly: review user list for EHR/email/cloud and remove stale accounts.
- After incidents: reset credentials and review privileged access.

## 8. Compliance & review
Reviewed at least annually and after major system changes.

**Approval:** ____________________  **Date:** __________
