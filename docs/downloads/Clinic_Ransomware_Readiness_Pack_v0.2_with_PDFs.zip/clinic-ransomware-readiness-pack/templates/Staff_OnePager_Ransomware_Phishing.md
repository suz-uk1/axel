# Staff One‑Pager: Ransomware & Phishing Basics (Clinic)

## If you see something weird, do this first
1) **Stop using the PC immediately**
2) **Disconnect from the network** (turn off Wi‑Fi / unplug cable)
3) **Call the clinic manager**
4) Do **not** try to “fix it” yourself

## What ransomware looks like
- files won’t open and have strange names
- pop-up/ransom note asking for money
- many PCs suddenly slow or failing
- you cannot access patient records

## Common phishing tricks
- “Invoice attached” you weren’t expecting
- “Password expires today” panic messages
- links that look real but go to a different site
- requests to change bank details/payment info

## Safe habits (simple)
- Don’t open unexpected attachments
- Don’t enable macros
- When in doubt: ask before clicking
- Verify money/bank changes by phone using known numbers

## If you clicked a suspicious link or opened an attachment
- Tell the clinic manager immediately
- Disconnect from Wi‑Fi
- Note what you clicked and when

**Emergency contact:** <Name/Phone>
