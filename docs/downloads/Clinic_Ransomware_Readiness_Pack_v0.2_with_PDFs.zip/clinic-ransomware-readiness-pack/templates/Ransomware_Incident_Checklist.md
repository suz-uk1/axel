# Ransomware Incident Checklist (Clinic)

**Print this.** Keep 1 copy at reception/admin desk + 1 in the clinic manager’s binder.

**Emergency contacts (fill in):**
- Clinic manager / owner: <Name> <Phone>
- IT provider: <Company/Name> <Phone> <Email>
- EHR / practice system vendor: <Name> <Phone>
- Backup provider / admin: <Name> <Phone>
- Building / network equipment (router/ISP): <ISP> <Phone>

## 0) If you suspect ransomware (any staff)
If you see any of these:
- files suddenly renamed/encrypted
- ransom note
- you cannot open patient records
- many PCs behaving strangely at once

**Do this immediately:**
1) **Stop using the device.**
2) **Disconnect from network** (unplug LAN / turn off Wi‑Fi).
3) **Call the clinic manager**.
4) Do **not** pay or negotiate.

---

## 1) First 60 minutes (containment + safety)
**Owner:** Clinic manager + IT provider

1) **Declare an incident** (start an incident log with timestamps).
2) **Isolate affected devices**:
   - Disconnect impacted PCs/servers from network.
   - If widespread, consider disconnecting clinic network from the internet (with IT guidance).
3) **Preserve evidence**:
   - Photograph ransom note screens.
   - Do not wipe devices.
   - Note which systems are affected.
4) **Assess patient safety + operations**:
   - Can you access the day’s schedule?
   - Can you safely continue appointments without records?
   - Decide: continue limited ops vs pause.
5) **Contact critical vendors** (IT, EHR, backup) and request immediate support.
6) **Prevent spread**:
   - Disable shared admin accounts if compromised.
   - Reset passwords for key accounts **from a known-clean device**.
7) **Backups protection**:
   - Confirm immutable/offline backups are safe.
   - Pause backup jobs if they could capture encrypted data.

---

## 2) First 24 hours (stabilize + restore planning)
1) **Impact assessment**:
   - What systems are down? (EHR, billing, imaging, files, email)
   - Any exfiltration indicators? (unusual outbound traffic, vendor alerts)
2) **Decide restoration approach** (with IT/vendor):
   - clean rebuild vs decrypt (assume rebuild)
   - prioritize: EHR/scheduling → billing → file shares → endpoints
3) **Communications**:
   - Internal staff briefing: what happened, what to do, what not to do.
   - Vendor coordination: one point of contact.
4) **Document everything** in the Evidence & Timeline worksheet.
5) **Restore test**:
   - Restore a small sample first to validate backup integrity.
   - Then proceed with priority systems.

---

## 3) Within 7 days (recovery + hardening)
1) **Complete restoration** and validate key workflows.
2) **Root cause review** (likely entry: phishing, exposed RDP, weak credentials, unpatched software).
3) **Minimum hardening actions**:
   - enforce MFA where possible
   - patch critical systems
   - remove shared admin accounts
   - confirm backups are immutable/offline
4) **Staff refresher**: phishing + reporting procedure.
5) **Post-incident review**:
   - what worked / what failed
   - update checklist and policies

---

## 4) Notes / incident log (timestamps)
- <YYYY-MM-DD HH:MM> — 
- 
