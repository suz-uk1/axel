# Clinic Ransomware Readiness Pack (APPI‑friendly)

## Hero
**Get your clinic ready for ransomware—without hiring expensive consultants.**

A practical, Japan‑clinic‑friendly kit of templates and checklists to:
- reduce the chance of an incident
- respond fast if it happens
- show reasonable safeguards around patient data (APPI)

**CTA:** Get the Pack

---

## Who it’s for
- Small clinics and dental practices (1–30 staff)
- Owners / administrators who handle vendors and IT “as needed”
- Clinics that store patient info in EHR / cloud storage / local PCs

Not for: large hospitals with dedicated security teams.

---

## The problem (what you’re dealing with)
Ransomware is no longer “big-company only.” For clinics, one incident can mean:
- cancelled appointments + lost revenue
- inability to access patient records
- stressful communications with vendors, insurers, and patients
- uncertainty about what to report and how to document actions

Most clinics don’t need a full security program—they need **clear, executable steps**.

---

## The outcome (what you get)
In a few hours, you’ll have a simple, documented baseline that covers:
- basic prevention controls (that small teams can actually keep)
- a ready-to-use incident response checklist
- staff-ready guidance (what to do / not do)
- vendor questions that surface common weak points

---

## What’s inside (deliverables)
### 1) Clinic Ransomware Incident Checklist (printable)
A step-by-step “do this now” list for the first 60 minutes, 24 hours, and 7 days.

### 2) APPI‑friendly Security Policy Pack (editable)
Short policies you can adopt and show to stakeholders.

### 3) Staff One‑Page: Ransomware & Phishing Basics
A simple handout for non-technical staff.

### 4) Vendor / IT Provider Questionnaire
Questions to ask your IT vendor, EHR vendor, and backup provider.

### 5) Evidence & Timeline Worksheet
A worksheet to record actions, timestamps, contacts, and decisions.

**Formats:** Google Docs + Word + PDF (where appropriate)

---

## How it works
1) Download the pack
2) Fill in your clinic details (15–30 minutes)
3) Run a 30-minute “tabletop” using the incident checklist
4) Share the staff one-pager and vendor questionnaire

---

## Why this is different
- **Small-clinic realistic:** minimal jargon, minimal overhead
- **Actionable:** checklists + ready-to-edit templates
- **Documentation-ready:** designed to leave a clean paper trail

---

## Pricing (placeholder)
**¥29,800** one-time (includes updates for 12 months)

**CTA:** Get the Pack

---

## FAQ (starter)
**Q: Do I need special software?**
No. This is a template kit + checklists.

**Q: Is this legal advice?**
No—this is operational guidance and templates. For legal decisions, consult a qualified professional.

**Q: Can my IT vendor use this?**
Yes. Many clinics will complete it with their vendor.

---

## Footer
© Clinic Ransomware Readiness Pack. All rights reserved.
