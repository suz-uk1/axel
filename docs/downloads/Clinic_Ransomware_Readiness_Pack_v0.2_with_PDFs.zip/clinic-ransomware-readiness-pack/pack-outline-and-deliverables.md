# Clinic Ransomware Readiness Pack (APPI‑friendly)

## Goal
A minimal, clinic‑realistic set of documents that (1) reduces ransomware likelihood, (2) speeds response, and (3) creates a clean, defensible record of “reasonable safeguards” for patient data handling.

## Pack structure (Table of Contents)
1. **Quick Start (read me first)**
   - What this pack is / isn’t
   - How to complete in 2–3 hours
   - Where to store documents (shared drive + printed binder)

2. **Incident Response (Ransomware) Toolkit**
   - IR Checklist (first 60 minutes / 24 hours / 7 days)
   - Communications mini‑script (internal + vendor)
   - Evidence & Timeline worksheet

3. **Clinic Security Baseline (APPI‑friendly) Policies**
   - Access control & account management
   - Device & software update policy
   - Backup & restore policy
   - Phishing & email handling policy
   - Removable media policy

4. **Staff Training (5–10 min micro‑training)**
   - Staff one‑pager: ransomware & phishing basics
   - “If you suspect something” flowchart

5. **Vendor / IT Provider Management**
   - Vendor questionnaire (IT provider/EHR/vendor)
   - Backup readiness checklist (questions + required evidence)

6. **Appendices**
   - Clinic asset inventory (lightweight)
   - Optional tabletop exercise guide (30 minutes)

---

## Deliverables list (what the customer receives)
**Core (included):**
1) `README_QuickStart.pdf` + editable doc
2) `Ransomware_Incident_Checklist.pdf` + editable doc
3) `Evidence_Timeline_Worksheet.xlsx` (or Google Sheet) + PDF
4) `Policy_AccessControl.docx`
5) `Policy_Updates_Patching.docx`
6) `Policy_Backup_Restore.docx`
7) `Policy_Phishing_Email.docx`
8) `Policy_RemovableMedia.docx`
9) `Staff_OnePager_Ransomware_Phishing.pdf` + editable doc
10) `Suspected_Incident_Flowchart.pdf`
11) `Vendor_Questionnaire_IT_EHR.docx`
12) `Backup_Readiness_Checklist.docx`
13) `Clinic_Asset_Inventory.xlsx` (lightweight)
14) `Tabletop_Exercise_Guide_30min.pdf`

**Nice-to-have (later upsell / v2):**
- Business continuity mini‑plan (downtime procedures)
- Patient notification decision tree (jurisdiction-specific; keep high-level)
- Simple risk register template

---

## “2–3 hour completion” plan
- 20 min: fill Quick Start clinic details + choose document owner
- 30 min: complete Vendor questionnaire and send to IT/EHR/backup vendors
- 30 min: tailor IR checklist + print it + add emergency contacts
- 20 min: set backup policy + confirm restore test schedule
- 10 min: distribute staff one‑pager + explain “suspected incident” flow
- 30 min: run the tabletop exercise

